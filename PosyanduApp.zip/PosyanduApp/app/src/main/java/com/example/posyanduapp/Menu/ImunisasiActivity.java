package com.example.posyanduapp.Menu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.posyanduapp.Login.LoginActivity;
import com.example.posyanduapp.R;
import com.example.posyanduapp.ViewHolder.DataImunisasi;
import com.example.posyanduapp.ViewHolder.ListDataImunisasi;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import static android.text.TextUtils.isEmpty;

public class ImunisasiActivity extends AppCompatActivity {
    EditText nmBalita, ketVaksin;
    Button btSimpanPerubahan2, btLhtData;
    CheckBox cb1, cb2, cb3, cb4, cb5, cb6, cb7;
    private int usertype;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    DataImunisasi dataImunisasi;
    int i =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imunisasi);

        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("catatan_imunisasi");
        dataImunisasi = new DataImunisasi();

        nmBalita = findViewById(R.id.nm_balita_imun);
        ketVaksin = findViewById(R.id.ket_imun);
        btSimpanPerubahan2 = findViewById(R.id.bt_simpan_perubahan2);
        btLhtData = findViewById(R.id.bt_lhtData_imun);
        cb1 = findViewById(R.id.cb_1);
        cb2 = findViewById(R.id.cb_2);
        cb3 = findViewById(R.id.cb_3);
        cb4 = findViewById(R.id.cb_4);
        cb5 = findViewById(R.id.cb_5);
        cb6 = findViewById(R.id.cb_6);
        cb7 = findViewById(R.id.cb_7);

        btLhtData.setOnClickListener((View v) -> startActivity(new Intent(ImunisasiActivity.this, ListDataImunisasi.class)));

        String cb_1 = "HB 0";
        String cb_2 = "BCG, Polio 1";
        String cb_3 = "DPT-HB-Hib 1, Polio 2";
        String cb_4 = "DPT-HB-Hib 2, Polio 3";
        String cb_5 = "DPT-HB-Hib 3, Polio 4, IPV";
        String cb_6 = "Campak";
        String cb_7 = "DPT-HB-Hib lanjutan dan Campak Lanjutan";

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    i = (int) snapshot.getChildrenCount();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        btSimpanPerubahan2.setOnClickListener(v -> {

            LoginActivity loginActivity = new LoginActivity();
            if(usertype == 0){
                btSimpanPerubahan2.setVisibility( View.GONE );
                btSimpanPerubahan2.setVisibility( View.INVISIBLE );
            }
            if(usertype == 1){
                btSimpanPerubahan2.setVisibility( View.VISIBLE );
            }

            String namaBalitaImun = nmBalita.getText().toString();
            String ketImun = ketVaksin.getText().toString();

            if(isEmpty(namaBalitaImun) && isEmpty(ketImun)){
                Toast.makeText(ImunisasiActivity.this, "Tambahkan Data", Toast.LENGTH_LONG).show();
            } else {
                addDatatoFirebase(namaBalitaImun, ketImun);
            }

            if(cb1.isChecked()){
                dataImunisasi.setVaksin1(cb_1);
                databaseReference.child(namaBalitaImun).setValue(dataImunisasi);
            }
            if(cb2.isChecked()){
                dataImunisasi.setVaksin2(cb_2);
                databaseReference.child(namaBalitaImun).setValue(dataImunisasi);
            }
            if(cb3.isChecked()){
                dataImunisasi.setVaksin3(cb_3);
                databaseReference.child(namaBalitaImun).setValue(dataImunisasi);
            }
            if(cb4.isChecked()){
                dataImunisasi.setVaksin4(cb_4);
                databaseReference.child(namaBalitaImun).setValue(dataImunisasi);
            }
            if(cb5.isChecked()){
                dataImunisasi.setVaksin5(cb_5);
                databaseReference.child(namaBalitaImun).setValue(dataImunisasi);
            }
            if(cb6.isChecked()){
                dataImunisasi.setVaksin6(cb_6);
                databaseReference.child(namaBalitaImun).setValue(dataImunisasi);
            }
            if(cb7.isChecked()){
                dataImunisasi.setVaksin7(cb_7);
                databaseReference.child(namaBalitaImun).setValue(dataImunisasi);
            }
        });
    }

    private void addDatatoFirebase(String namaBalitaImun, String ketImun){
        dataImunisasi.setNamaBalita(namaBalitaImun);
        dataImunisasi.setKetImunisasi(ketImun);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                databaseReference.child(namaBalitaImun).setValue(dataImunisasi);
                Toast.makeText(ImunisasiActivity.this, "Data Ditambahkan", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                databaseReference.child(namaBalitaImun).setValue(dataImunisasi);
                Toast.makeText(ImunisasiActivity.this, "Data Gagal Ditambahkan" + error, Toast.LENGTH_LONG).show();
            }
        });
    }
}