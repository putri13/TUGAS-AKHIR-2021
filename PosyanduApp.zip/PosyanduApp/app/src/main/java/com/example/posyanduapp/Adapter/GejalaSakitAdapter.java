package com.example.posyanduapp.Adapter;

import com.example.posyanduapp.Menu.BatukFragment;
import com.example.posyanduapp.Menu.DemamFragment;
import com.example.posyanduapp.Menu.DiareFragment;
import com.example.posyanduapp.Menu.LukaFragment;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class GejalaSakitAdapter extends FragmentPagerAdapter {



    public GejalaSakitAdapter(@NonNull FragmentManager fragmentManager){
        super(fragmentManager);
    }

    @NonNull
    @Override
    public Fragment getItem (int position){
        Fragment fragment = null;
        if (position == 0)
            fragment = new BatukFragment();
        else if (position == 1)
            fragment = new DiareFragment();
        else if (position == 2)
            fragment = new DemamFragment();
        else if (position == 3)
            fragment = new LukaFragment();
        return fragment;
    }

    @Override
    public int getCount() {
        return 4;
    }

    @Override
    public CharSequence getPageTitle (int position){
            String title = null;
            if (position == 0)
                title = "Batuk";
            else if (position == 1)
                title = "Diare/Mencret";
            else if (position == 2)
                title = "Demam";
            else if (position == 3)
                title = "Luka dan Koreng";
            return title;
        }



    }




