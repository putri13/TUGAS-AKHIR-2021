package com.example.posyanduapp.Login;

import android.os.Bundle;

import com.example.posyanduapp.R;
import com.example.posyanduapp.Menu.EditProfilFragment;
import com.example.posyanduapp.Menu.MenuAdmin;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class HomeAdminActivity extends AppCompatActivity {


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_admin );

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_nav);
        bottomNavigationView.setOnNavigationItemReselectedListener(navListener);
    }

    private final BottomNavigationView.OnNavigationItemReselectedListener navListener=
            item -> {
                Fragment selectedFragment = null;
                switch (item.getItemId()) {
                    case R.id.nav_menu:
                        selectedFragment = new MenuAdmin();
                        break;
                    case R.id.nav_profil:
                        selectedFragment = new EditProfilFragment();
                        break;
                }
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_cont,selectedFragment).commit();
            };
}
