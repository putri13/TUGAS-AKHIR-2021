package com.example.posyanduapp.Adapter;

import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.posyanduapp.R;
import com.example.posyanduapp.ViewHolder.RegistBalita;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class BalitaAdapter extends FirebaseRecyclerAdapter
        <RegistBalita, BalitaAdapter.BalitaViewHolder>  {


    public BalitaAdapter(
            @NonNull FirebaseRecyclerOptions<RegistBalita> options)
    {
        super(options);
    }



    @NonNull
    @Override
    public BalitaViewHolder onCreateViewHolder
            (@NonNull ViewGroup parent, int viewType){

    View view = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.activity_regist_balita, parent, false);
    return new BalitaAdapter.BalitaViewHolder(view);
    }


    @Override
    protected void onBindViewHolder(
            @NonNull BalitaViewHolder holder, int position, @NonNull RegistBalita model) {

        //holder.spinner.setAdapter( (SpinnerAdapter) b );
        holder.namaAnak.setText(model.getNamaAnak());
        holder.tglLAhir.setText(model.getTtlAnak());
        holder.anakKe.setText(model.getAnakKe());
        holder.jenisKelamin.setText(model.getGender());
        holder.nikAnak.setText(model.getNikAnak());
        holder.bbAnak.setText(model.getBbAnak());
        holder.namAyah.setText(model.getNamaOrtu1());
        holder.namaIbu.setText(model.getNamaOrtu2());
        holder.nikAyah.setText(model.getNikOrtu1());
        holder.nikIbu.setText(model.getNikOrtu2());
        holder.noTelepon.setText(model.getNoTeleponOrtu());
        holder.alamat.setText(model.getAlamatOrtu());
        holder.btHapus.setOnClickListener((v ->  {
            AlertDialog.Builder builder = new AlertDialog.Builder(holder.btHapus.getContext());
            builder.setTitle("Hapus Item");
            builder.setTitle("Apakah Anda yakin akan menghapus data ini?");

            builder.setPositiveButton("Ya", (dialog, i) -> FirebaseDatabase.getInstance().getReference().child("regist_balita")
                    .child( Objects.requireNonNull(getRef(position).getKey())).removeValue());
            builder.setNegativeButton("Tidak", (dialog, i) -> {

            });
            builder.show();
        }));

    }



    class BalitaViewHolder extends RecyclerView.ViewHolder{
        TextView btEdit, btHapus, namaAnak, tglLAhir, anakKe, jenisKelamin, nikAnak, bbAnak, namAyah, nikAyah, namaIbu, nikIbu, noTelepon, alamat;
        Spinner spinner;
        public BalitaViewHolder(@NonNull View itemView) {
            super(itemView);

            //namaOrtu = itemView.findViewById( R.id.namaortu );
            namaAnak = itemView.findViewById(R.id.tanggalPemeriksaan);
            tglLAhir = itemView.findViewById(R.id.namaBalita);
            anakKe = itemView.findViewById(R.id.beratBadan);
            jenisKelamin = itemView.findViewById(R.id.et_gender );
            nikAnak = itemView.findViewById(R.id.lingkarKepala);
            bbAnak = itemView.findViewById(R.id.et_bb );
            namAyah = itemView.findViewById(R.id.namaAyah);
            namaIbu = itemView.findViewById(R.id.namaIbu);
            nikAyah = itemView.findViewById(R.id.nikAyah);
            nikIbu = itemView.findViewById(R.id.nikIbu);
            noTelepon = itemView.findViewById(R.id.noTelepon);
            alamat = itemView.findViewById(R.id.alamat);
            btHapus = itemView.findViewById(R.id.bt_hps_regist);


        }



    }
}