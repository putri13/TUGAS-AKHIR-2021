package com.example.posyanduapp.Login;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.posyanduapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import static com.google.firebase.auth.FirebaseAuth.AuthStateListener;
import static com.google.firebase.auth.FirebaseAuth.getInstance;

public class LoginActivity extends AppCompatActivity {

    EditText edEmail, edPassword;
    Button btnLogin, btnSignUp;
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("Users");
    FirebaseAuth firebaseAuth= getInstance();
    AuthStateListener authStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_login );


        edEmail = findViewById( R.id.email );
        edPassword = findViewById( R.id.pass );
        btnLogin = findViewById( R.id.btn_login );
        btnSignUp = findViewById( R.id.sign_up );

        btnSignUp.setOnClickListener( v -> {
            Intent intent = new Intent(LoginActivity.this, SignUp.class);
            startActivity( intent );
        } );

        btnLogin.setOnClickListener( v -> {

            if (edEmail.getText().toString().isEmpty()){
                Toast.makeText( getApplicationContext(), "Masukkan Email", Toast.LENGTH_SHORT).show();
            }
            if (edPassword.getText().toString().isEmpty()){
                Toast.makeText( getApplicationContext(), "Masukkan Password", Toast.LENGTH_SHORT ).show();
            }

            if (!(edEmail.getText().toString().isEmpty() && edPassword.getText().toString().isEmpty())){

                firebaseAuth.signInWithEmailAndPassword(edEmail.getText().toString(), edPassword.getText().toString())
                        .addOnCompleteListener( task -> {
                            if(task.isSuccessful()){

                                String uid = task.getResult().getUser().getUid();
                                databaseReference.child("Users").child(uid).child("usertype").addListenerForSingleValueEvent( new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        int usertype = snapshot.getValue(Integer.class);
                                        if(usertype==0){
                                            Intent intent = new Intent( LoginActivity.this, HomeOrtuActivity.class);

                                            Toast.makeText( getApplicationContext(), "Berhasil Login", Toast.LENGTH_LONG).show();
                                            startActivity( intent );
                                        }

                                        if(usertype==1){
                                            Intent intent = new Intent( LoginActivity.this, HomeAdminActivity.class);
                                            Toast.makeText( getApplicationContext(), "Berhasil Login", Toast.LENGTH_LONG).show();
                                            startActivity( intent );
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {
                                    }
                                } );
                            }

                            else {
                                Toast.makeText( getApplicationContext(), task.getException().getLocalizedMessage(), Toast.LENGTH_LONG ).show();
                            }
                        } );

                Intent intent = new Intent(LoginActivity.this, HomeOrtuActivity.class);
                startActivity( intent );

            }
        } );


    }



}