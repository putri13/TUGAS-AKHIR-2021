package com.example.posyanduapp.ViewHolder;

import android.os.Bundle;

import com.example.posyanduapp.Adapter.KMSAdapter;
import com.example.posyanduapp.R;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


public class ListDataKMS extends AppCompatActivity {

    KMSAdapter kmsAdapter;
    DatabaseReference reference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_data_k_m_s);

        reference = FirebaseDatabase.getInstance().getReference().child("data_pemeriksaan");
        RecyclerView recyclerView2 = findViewById(R.id.list_kms);

        recyclerView2.setLayoutManager(new LinearLayoutManager(this));

        FirebaseRecyclerOptions<DataPemeriksaan>
        options = new FirebaseRecyclerOptions.Builder<DataPemeriksaan>()
                .setQuery(reference, DataPemeriksaan.class)
                .build();

        kmsAdapter = new KMSAdapter(options);

        recyclerView2.setAdapter(kmsAdapter);
        recyclerView2.setHasFixedSize(true);


    }

    @Override
    protected void onStart(){
        super.onStart();
        kmsAdapter.startListening();
    }
    @Override
    protected void onStop(){
        super.onStop();
        kmsAdapter.stopListening();
    }
}