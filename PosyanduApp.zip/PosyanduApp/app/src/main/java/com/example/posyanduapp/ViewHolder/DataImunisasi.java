package com.example.posyanduapp.ViewHolder;

public class DataImunisasi {


    private String Imunisasi;
    private String namaBalita;
    private String vaksin1;
    private String vaksin2;
    private String vaksin3;
    private String vaksin4;
    private String vaksin5;
    private String vaksin6;
    private String vaksin7;
    private String ketImunisasi;

    public String getKetImunisasi() {
        return ketImunisasi;
    }

    public void setKetImunisasi(String ketImunisasi) {
        this.ketImunisasi = ketImunisasi;
    }



    public String getNamaBalita() {
        return namaBalita;
    }

    public void setNamaBalita(String namaBalita) {
        this.namaBalita = namaBalita;
    }

    public String getVaksin1() {
        return vaksin1;
    }

    public void setVaksin1(String vaksin1) {
        this.vaksin1 = vaksin1;
    }

    public String getVaksin2() {
        return vaksin2;
    }

    public void setVaksin2(String vaksin2) {
        this.vaksin2 = vaksin2;
    }

    public String getVaksin3() {
        return vaksin3;
    }

    public void setVaksin3(String vaksin3) {
        this.vaksin3 = vaksin3;
    }

    public String getVaksin4() {
        return vaksin4;
    }

    public void setVaksin4(String vaksin4) {
        this.vaksin4 = vaksin4;
    }

    public String getVaksin5() {
        return vaksin5;
    }

    public void setVaksin5(String vaksin5) {
        this.vaksin5 = vaksin5;
    }

    public String getVaksin6() {
        return vaksin6;
    }

    public void setVaksin6(String vaksin6) {
        this.vaksin6 = vaksin6;
    }

    public String getVaksin7() {
        return vaksin7;
    }

    public void setVaksin7(String vaksin7) {
        this.vaksin7 = vaksin7;
    }

    public String getImunisasi() {
        return Imunisasi;
    }

    public void setImunisasi(String imunisasi) {
        Imunisasi = imunisasi;
    }


    public DataImunisasi(){

    }


}
