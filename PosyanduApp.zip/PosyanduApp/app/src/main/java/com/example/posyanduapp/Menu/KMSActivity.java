package com.example.posyanduapp.Menu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.posyanduapp.Login.LoginActivity;
import com.example.posyanduapp.R;
import com.example.posyanduapp.ViewHolder.DataPemeriksaan;
import com.example.posyanduapp.ViewHolder.ListDataKMS;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import static android.text.TextUtils.isEmpty;

public class KMSActivity extends AppCompatActivity {

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("data_pemeriksaan");
    EditText tglPemeriksaan, namaBalita, beratBadan, tinggiBadan, lingkarKepala, ketPemeriksaan;


    private int usertype;
    DataPemeriksaan dataPemeriksaan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_k_m_s);

        tglPemeriksaan = findViewById(R.id.tgl_pemeriksaan);
        namaBalita = findViewById(R.id.nama_balita);
        ketPemeriksaan = findViewById(R.id.ket_pemeriksaan);
        beratBadan = findViewById(R.id.x_value);
        tinggiBadan = findViewById(R.id.y_value);
        lingkarKepala = findViewById(R.id.z_value);

        firebaseDatabase = FirebaseDatabase.getInstance();
        dataPemeriksaan = new DataPemeriksaan();

        Button btSimpan3 = findViewById(R.id.bt_simpan3);
        Button btLihat = findViewById(R.id.bt_lihat_kms);
        //Button btApdet = findViewById(R.id.bt_upd_kms);
        //Button btHapus = findViewById(R.id.bt_hapus_kms);


        btLihat.setOnClickListener((View v) -> startActivity(new Intent(KMSActivity.this, ListDataKMS.class)));
        btSimpan3.setOnClickListener((View v) -> {
            LoginActivity loginActivity = new LoginActivity();
            if(usertype == 0){
                btSimpan3.setVisibility( View.GONE );
                btSimpan3.setVisibility( View.INVISIBLE );
            }
            if(usertype == 1){
                btSimpan3.setVisibility( View.VISIBLE );
            }
                String beratAnak = beratBadan.getText().toString();
                String tinggiAnak = tinggiBadan.getText().toString();
                String lingkarKepalaAnak = lingkarKepala.getText().toString();
                String tglPeriksa = tglPemeriksaan.getText().toString();
                String nmBalita = namaBalita.getText().toString();
                String ketPeriksa = ketPemeriksaan.getText().toString();

                if(isEmpty(beratAnak) && isEmpty(tinggiAnak) && isEmpty(lingkarKepalaAnak) && isEmpty(tglPeriksa) && isEmpty(nmBalita) && isEmpty(ketPeriksa)){
                    Toast.makeText(KMSActivity.this, "Tambahkan Data", Toast.LENGTH_LONG).show();
                }else {
                    addDatatoFirebase(beratAnak, tinggiAnak, lingkarKepalaAnak, tglPeriksa, nmBalita, ketPeriksa);
                }
        });

        //btApdet.setOnClickListener((View v) -> startActivity(new Intent(KMSActivity.this, UpdateKMS.class)));

    }


    private void addDatatoFirebase(String beratAnak, String tinggiAnak, String lingkarKepalaAnak,String tglPeriksa, String nmBalita, String ketPeriksa) {

        dataPemeriksaan.setBeratBadan(beratAnak);
        dataPemeriksaan.setTinggiBadan(tinggiAnak);
        dataPemeriksaan.setLingkarKepala(lingkarKepalaAnak);
        dataPemeriksaan.setNamaBalita(nmBalita);
        dataPemeriksaan.setTglPemeriksaan(tglPeriksa);
        dataPemeriksaan.setKetPemeriksaan(ketPeriksa);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                databaseReference.child(nmBalita).setValue(dataPemeriksaan);
                Toast.makeText(KMSActivity.this, "Data Ditambahkan", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(KMSActivity.this, "Gagal Menambahkan Data" + error, Toast.LENGTH_LONG).show();
            }
        });
    }


}