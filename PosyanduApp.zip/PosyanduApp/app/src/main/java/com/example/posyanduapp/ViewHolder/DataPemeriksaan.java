package com.example.posyanduapp.ViewHolder;

import java.io.Serializable;

public class DataPemeriksaan implements Serializable {

    private String namaBalita;
    private String tglPemeriksaan;
    private String ketPemeriksaan;
    private String beratBadan;
    private String tinggiBadan;
    private String lingkarKepala;

    public String getNamaBalita() {
        return namaBalita;
    }

    public String getTglPemeriksaan() {
        return tglPemeriksaan;
    }

    public String getKetPemeriksaan() {
        return ketPemeriksaan;
    }




    public void setNamaBalita(String namaBalita) {
        this.namaBalita = namaBalita;
    }

    public void setTglPemeriksaan(String tglPemeriksaan) {
        this.tglPemeriksaan = tglPemeriksaan;
    }

    public void setKetPemeriksaan(String ketPemeriksaan) {
        this.ketPemeriksaan = ketPemeriksaan;
    }




    public String getBeratBadan() {
        return beratBadan;
    }

    public void setBeratBadan(String beratBadan) {
        this.beratBadan = beratBadan;
    }

    public String getTinggiBadan() {
        return tinggiBadan;
    }

    public void setTinggiBadan(String tinggiBadan) {
        this.tinggiBadan = tinggiBadan;
    }

    public String getLingkarKepala() {
        return lingkarKepala;
    }

    public void setLingkarKepala(String lingkarKepala) {
        this.lingkarKepala = lingkarKepala;
    }




    public DataPemeriksaan(){

    }


}