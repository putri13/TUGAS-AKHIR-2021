package com.example.posyanduapp.ViewHolder;

import java.io.Serializable;

public class RegistBalita implements Serializable {

    private String namaAnak;
    private String ttlAnak;
    private String anakKe;
    private String gender;
    private String nikAnak;
    private String bbAnak;
    private String namaOrtu1;
    private String namaOrtu2;
    private String nikOrtu1;
    private String nikOrtu2;
    private String noTeleponOrtu;
    private String alamatOrtu;
    private String userId;

    public String getSpinner() {
        return spinner;
    }

    public void setSpinner(String spinner) {
        this.spinner = spinner;
    }

    //private String id;
    private String spinner;









    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }



    public String getNamaAnak() {
        return namaAnak;
    }

    public void setNamaAnak(String namaAnak) {
        this.namaAnak = namaAnak;
    }

    public String getTtlAnak() {
        return ttlAnak;
    }

    public void setTtlAnak(String ttlAnak) {
        this.ttlAnak = ttlAnak;
    }

    public String getAnakKe() {
        return anakKe;
    }

    public void setAnakKe(String anakKe) {
        this.anakKe = anakKe;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getNikAnak() {
        return nikAnak;
    }

    public void setNikAnak(String nikAnak) {
        this.nikAnak = nikAnak;
    }

    public String getBbAnak() {
        return bbAnak;
    }

    public void setBbAnak(String bbAnak) {
        this.bbAnak = bbAnak;
    }

    public String getNamaOrtu1() {
        return namaOrtu1;
    }

    public void setNamaOrtu1(String namaOrtu1) {
        this.namaOrtu1 = namaOrtu1;
    }

    public String getNamaOrtu2() {
        return namaOrtu2;
    }

    public void setNamaOrtu2(String namaOrtu2) {
        this.namaOrtu2 = namaOrtu2;
    }

    public String getNikOrtu1() {
        return nikOrtu1;
    }

    public void setNikOrtu1(String nikOrtu1) {
        this.nikOrtu1 = nikOrtu1;
    }

    public String getNikOrtu2() {
        return nikOrtu2;
    }

    public void setNikOrtu2(String nikOrtu2) {
        this.nikOrtu2 = nikOrtu2;
    }

    public String getNoTeleponOrtu() {
        return noTeleponOrtu;
    }

    public void setNoTeleponOrtu(String noTeleponOrtu) {
        this.noTeleponOrtu = noTeleponOrtu;
    }

    public String getAlamatOrtu() {
        return alamatOrtu;
    }

    public void setAlamatOrtu(String alamatOrtu) {
        this.alamatOrtu = alamatOrtu;
    }





    public RegistBalita() {

    }




    }
