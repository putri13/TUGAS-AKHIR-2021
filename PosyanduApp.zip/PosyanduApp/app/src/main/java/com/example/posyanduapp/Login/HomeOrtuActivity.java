package com.example.posyanduapp.Login;

import android.os.Bundle;

import com.example.posyanduapp.R;
import com.example.posyanduapp.Menu.EditProfilFragment;
import com.example.posyanduapp.Menu.MenuOrtu;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;


public class HomeOrtuActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_ortu);

        //Intent intent = new Intent(this, Notifikasi.class);
        //startService(intent);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_nav);
        bottomNavigationView.setOnNavigationItemSelectedListener(navListener);

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_cont,
                new MenuOrtu()).commit();
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener=
            item -> {
                Fragment selectedFragment = null;
                switch (item.getItemId()) {
                    case R.id.nav_menu:
                        selectedFragment = new MenuOrtu();
                        break;
                    case R.id.nav_profil:
                        selectedFragment = new EditProfilFragment();
                        break;
                }
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_cont,
                        selectedFragment).commit();
                return true;
            };




}
