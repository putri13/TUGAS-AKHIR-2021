package com.example.posyanduapp.ViewHolder;

import android.os.Bundle;

import com.example.posyanduapp.Adapter.PerkembanganAdapter;
import com.example.posyanduapp.R;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ListPerkembangan extends AppCompatActivity {

    PerkembanganAdapter perkembanganAdapter;
    DatabaseReference dbReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_perkembangan);

        dbReference = FirebaseDatabase.getInstance().getReference().child("catatan_perkembangan");
        RecyclerView recyclerView3 = findViewById(R.id.list_perkembangan);

        recyclerView3.setLayoutManager(new LinearLayoutManager(this));

        FirebaseRecyclerOptions<DataPerkembangan>
                options = new FirebaseRecyclerOptions.Builder<DataPerkembangan>()
                .setQuery(dbReference, DataPerkembangan.class)
                .build();

        perkembanganAdapter = new PerkembanganAdapter(options);
        recyclerView3.setAdapter(perkembanganAdapter);

    }

    @Override
    protected void onStart(){
        super.onStart();
        perkembanganAdapter.startListening();
    }
    @Override
    protected void onStop(){
        super.onStop();
        perkembanganAdapter.stopListening();

    }
}