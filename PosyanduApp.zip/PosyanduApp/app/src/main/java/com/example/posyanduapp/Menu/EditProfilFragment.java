package com.example.posyanduapp.Menu;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.posyanduapp.Login.LoginActivity;
import com.example.posyanduapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import de.hdodenhof.circleimageview.CircleImageView;

public class EditProfilFragment extends Fragment {

   private TextView nmOrtu, noTelp, emaill;
   private CircleImageView circleImageView;
   private DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("Users");

    Button btLogout;
   private FirebaseAuth firebaseAuth;
   String currentUserId;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate( R.layout.fragment_edit_profil, container, false );

        firebaseAuth = FirebaseAuth.getInstance();
        currentUserId = Objects.requireNonNull( firebaseAuth.getCurrentUser() ).getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference().child( "Users" ).child( "Users" ).child( currentUserId );

        nmOrtu = view.findViewById( R.id.p_nama );
        noTelp = view.findViewById( R.id.p_no );
        emaill = view.findViewById( R.id.p_email );
        circleImageView = view.findViewById( R.id.imageView3 );

        btLogout = view.findViewById( R.id.btn_logout );

        btLogout.setOnClickListener( v -> {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent( getActivity(), LoginActivity.class );
            intent.setFlags( Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK );
            Toast.makeText( getActivity(),"Berhasil Log Out", Toast.LENGTH_LONG ).show();
            startActivity( intent );

        } );

        databaseReference.addListenerForSingleValueEvent
                ( new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
            if(snapshot.exists()){
                //String foto = snapshot.child( "gambar" ).getValue().toString();
                String namaOrtu = snapshot.child( "nama" ).getValue().toString();
                String noTelepon = snapshot.child( "telepon" ).getValue().toString();
                String email = snapshot.child( "email" ).getValue().toString();

                //Picasso.get().load(foto).placeholder(R.drawable.ikon).into(circleImageView);

                nmOrtu.setText(   "@" + namaOrtu );
                noTelp.setText(  "No Telepon : " + noTelepon );
                emaill.setText(  "Email : " + email );
            }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        } );
        return view;
    }



}