package com.example.posyanduapp.Menu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.posyanduapp.Login.LoginActivity;
import com.example.posyanduapp.R;
import com.example.posyanduapp.ViewHolder.DataPerkembangan;
import com.example.posyanduapp.ViewHolder.ListPerkembangan;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import static android.text.TextUtils.isEmpty;

public class PerkembanganActivity extends AppCompatActivity {

    EditText namaBalita, ket1Perkembangan, ket2Perkembangan, ket3Perkembangan;
    Button btSimpanPerubahan;
    CheckBox cb1a, cb1b, cb1c, cb2a, cb2b, cb2c, cb2d, cb2e,
            cb3a, cb3b, cb3c, cb3d, cb3e, cb3f;

    private int usertype;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference reference;
    DataPerkembangan dataPerkembangan;
    int i = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perkembangan);

        firebaseDatabase = FirebaseDatabase.getInstance();
        reference = FirebaseDatabase.getInstance().getReference().child("catatan_perkembangan");
        dataPerkembangan = new DataPerkembangan();

        Button bt_lhtData_per = findViewById(R.id.bt_lhtData_per);

        bt_lhtData_per.setOnClickListener((View v) -> startActivity(new Intent(PerkembanganActivity.this, ListPerkembangan.class)));

        namaBalita = findViewById(R.id.nm_balita_cp);
        ket1Perkembangan = findViewById(R.id.ket1_cp);
        ket2Perkembangan = findViewById(R.id.ket2_cp);
        ket3Perkembangan = findViewById(R.id.ket3_cp);
        btSimpanPerubahan = findViewById(R.id.bt_simpan_perubahan);
        cb1a= findViewById(R.id.cb_1a);
        cb1b= findViewById(R.id.cb_1b);
        cb1c= findViewById(R.id.cb_1c);
        cb2a= findViewById(R.id.cb_2a);
        cb2b= findViewById(R.id.cb_2b);
        cb2c= findViewById(R.id.cb_2c);
        cb2d= findViewById(R.id.cb_2d);
        cb2e= findViewById(R.id.cb_2e);
        cb3a= findViewById(R.id.cb_3a);
        cb3b= findViewById(R.id.cb_3b);
        cb3c= findViewById(R.id.cb_3c);
        cb3d= findViewById(R.id.cb_3d);
        cb3e= findViewById(R.id.cb_3e);
        cb3f= findViewById(R.id.cb_3f);

        String cb_1a = "a. Menatap ke ibu";
        String cb_1b = "b. Mengeluarkan suara o.. o..";
        String cb_1c = "c. Tersenyum";
        String cb_2a = "a. Mengangkat kepala tegak ketika tengkurap";
        String cb_2b = "b. Tertawa";
        String cb_2c = "c. Menggerakkan kepala ke kiri dan kanan";
        String cb_2d = "d. Membalas tersenyum ketika diajak bicara/tersenyum";
        String cb_2e = "e. Mengoceh spontan atau bereaksi dengan mengoceh";
        String cb_3a = "a. Berbalik dari telungkup ke telentang";
        String cb_3b = "b. Mempertahankan posisi kepala tetap tegak";
        String cb_3c = "c. Meraih benda yang ada didekatnya";
        String cb_3d = "d. Menirukan bunyi";
        String cb_3e = "e. Menggenggam mainan";
        String cb_3f = "f. Tersenyum ketika melihat mainan/gambar yang menarik";

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    i = (int) snapshot.getChildrenCount();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

        btSimpanPerubahan.setOnClickListener(v -> {

            LoginActivity loginActivity = new LoginActivity();
            if(usertype == 0){
                btSimpanPerubahan.setVisibility( View.GONE );
                btSimpanPerubahan.setVisibility( View.INVISIBLE );
            }
            if(usertype == 1){
                btSimpanPerubahan.setVisibility( View.VISIBLE );
            }

            String nama = namaBalita.getText().toString();
            String ket1 = ket1Perkembangan.getText().toString();
            String ket2 = ket2Perkembangan.getText().toString();
            String ket3 = ket3Perkembangan.getText().toString();

            if(isEmpty(nama) && isEmpty(ket1) && isEmpty(ket2) && isEmpty(ket3)){
                Toast.makeText(PerkembanganActivity.this, "Tambahkan Data", Toast.LENGTH_LONG).show();
            } else {
                addDatatoFirebase(nama, ket1, ket2, ket3);
            }
            if (cb1a.isChecked()){
                dataPerkembangan.setPerkembangan1a(cb_1a);
                reference.child(nama).setValue(dataPerkembangan);
            }
            if (cb1b.isChecked()) {
                dataPerkembangan.setPerkembangan1b(cb_1b);
                reference.child(nama).setValue(dataPerkembangan);
            }
            if (cb1c.isChecked()){
                dataPerkembangan.setPerkembangan1c(cb_1c);
                reference.child(nama).setValue(dataPerkembangan);
            }
            if (cb2a.isChecked()){
                dataPerkembangan.setPerkembangan2a(cb_2a);
                reference.child(nama).setValue(dataPerkembangan);
            }
            if (cb2b.isChecked()){
                dataPerkembangan.setPerkembangan2b(cb_2b);
                reference.child(nama).setValue(dataPerkembangan);
            }
            if (cb2c.isChecked()){
                dataPerkembangan.setPerkembangan2c(cb_2c);
                reference.child(nama).setValue(dataPerkembangan);
            }
            if (cb2d.isChecked()) {
                dataPerkembangan.setPerkembangan2d(cb_2d);
                reference.child(nama).setValue(dataPerkembangan);
            }
            if (cb2e.isChecked()) {
                dataPerkembangan.setPerkembangan2e(cb_2e);
                reference.child(nama).setValue(dataPerkembangan);
            }
            if (cb3a.isChecked()) {
                dataPerkembangan.setPerkembangan3a(cb_3a);
                reference.child(nama).setValue(dataPerkembangan);
            }
            if (cb3b.isChecked()) {
                dataPerkembangan.setPerkembangan3b(cb_3b);
                reference.child(nama).setValue(dataPerkembangan);
            }
            if (cb3c.isChecked()) {
                dataPerkembangan.setPerkembangan3c(cb_3c);
                reference.child(nama).setValue(dataPerkembangan);
            }
            if (cb3d.isChecked()) {
                dataPerkembangan.setPerkembangan3d(cb_3d);
                reference.child(nama).setValue(dataPerkembangan);
            }
            if (cb3e.isChecked()) {
                dataPerkembangan.setPerkembangan3e(cb_3e);
                reference.child(nama).setValue(dataPerkembangan);
            }
            if (cb3f.isChecked()) {
                dataPerkembangan.setPerkembangan3f(cb_3f);
                reference.child(nama).setValue(dataPerkembangan);
            }
        });
    }

    private void addDatatoFirebase(String nama,String ket1, String ket2, String ket3) {
        dataPerkembangan.setNmBalita(nama);
        dataPerkembangan.setKet1(ket1);
        dataPerkembangan.setKet2(ket2);
        dataPerkembangan.setKet3(ket3);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                reference.child(nama).setValue(dataPerkembangan);
                Toast.makeText(PerkembanganActivity.this, "Data Ditambahkan", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                reference.child(nama).setValue(dataPerkembangan);
                Toast.makeText(PerkembanganActivity.this, "Data Gagal Ditambahkan" + error, Toast.LENGTH_LONG).show();
            }
        });
    }
}
