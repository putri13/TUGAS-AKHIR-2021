package com.example.posyanduapp.ViewHolder;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.posyanduapp.R;
import com.google.firebase.database.FirebaseDatabase;

import androidx.appcompat.app.AppCompatActivity;

import static android.text.TextUtils.isEmpty;

public class UpdateBalita extends AppCompatActivity {
    private EditText etNmAnak, etTtl, etAnakKe, etGender, etNikAnak, etBB,
    etNmAyah, etNikAyah, etNmIbu, etNikIbu, etNo, etAlamat;


    private FirebaseDatabase fb;

    @Override
    protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView( R.layout.update_balita);
        RegistBalita registBalita = (RegistBalita) getIntent().getSerializableExtra("regist_balita");

        fb = FirebaseDatabase.getInstance();

        etNmAnak = findViewById(R.id.et_nm_anak);
        etTtl = findViewById(R.id.et_tl_anak);
        etAnakKe = findViewById(R.id.et_anak_ke);
        etGender = findViewById(R.id.et_gender);
        etNikAnak = findViewById(R.id.et_nik_anak);
        etBB = findViewById(R.id.et_bb);
        etNmAyah = findViewById(R.id.et_nm_ortu1);
        etNikAyah = findViewById(R.id.et_nik_ortu1);
        etNmIbu = findViewById(R.id.et_nm_ortu2);
        etNikIbu = findViewById(R.id.et_nik_ortu2);
        etNo = findViewById(R.id.et_nt_ortu);
        etAlamat = findViewById(R.id.et_al_ortu);
        Button btApdet = findViewById(R.id.bt_detail_apdet_regist );

        btApdet.setOnClickListener( v -> {
            String namaLengkapAnak = etNmAnak.getText().toString();
            String ttlAnak = etTtl.getText().toString();
            String anakKeBerapa = etAnakKe.getText().toString();
            String genderAnak = etGender.getText().toString();
            String nik_Anak = etNikAnak.getText().toString();
            String beratBadanAnak = etBB.getText().toString();
            String namaOrtu1 = etNmAyah.getText().toString();
            String namaOrtu2 = etNmIbu.getText().toString();
            String nik_Ortu1 = etNikAyah.getText().toString();
            String nik_Ortu2 = etNikIbu.getText().toString();
            String noTeleponOrtu = etNo.getText().toString();
            String alamatOrtu = etAlamat.getText().toString();

            if (isEmpty(namaLengkapAnak) && isEmpty(ttlAnak) && isEmpty(anakKeBerapa) &&
                    isEmpty(genderAnak) && isEmpty(nik_Anak) && isEmpty(beratBadanAnak) && isEmpty(namaOrtu1) && isEmpty(namaOrtu2) &&
                    isEmpty(nik_Ortu1) && isEmpty(nik_Ortu2) && isEmpty(noTeleponOrtu) && isEmpty(alamatOrtu)) {
                Toast.makeText( UpdateBalita.this, "Tambahkan Data Anda", Toast.LENGTH_LONG).show();
            } else {
                updateBalita(registBalita, namaLengkapAnak, ttlAnak, anakKeBerapa, genderAnak, nik_Anak,
                        beratBadanAnak, namaOrtu1, namaOrtu2, nik_Ortu1, nik_Ortu2, noTeleponOrtu, alamatOrtu);
            }
        } );

    }

    private void updateBalita(RegistBalita registBalita, String namaLengkapAnak, String ttlAnak,
                              String anakKeBerapa, String genderAnak, String nik_anak, String beratBadanAnak,
                              String namaOrtu1, String namaOrtu2, String nik_ortu1, String nik_ortu2, String noTeleponOrtu, String alamatOrtu) {
        RegistBalita updateBalita = new RegistBalita();

        fb.getReference().child("regist_balita").setValue(updateBalita)
                .addOnSuccessListener( aVoid -> Toast.makeText( UpdateBalita.this, "Data telah diupdate", Toast.LENGTH_LONG).show())
                .addOnFailureListener( e -> {
        } );
    }


}
