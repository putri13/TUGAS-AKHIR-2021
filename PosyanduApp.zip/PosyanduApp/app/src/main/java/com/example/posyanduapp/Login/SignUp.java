package com.example.posyanduapp.Login;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.posyanduapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import androidx.appcompat.app.AppCompatActivity;

public class SignUp extends AppCompatActivity {


    Button btnDaftar, btnLogin2;
    //FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("Users");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_sign_up );

        final EditText etNama = findViewById( R.id.p_nm );
        final EditText etTelepon = findViewById( R.id.p_telp );
        final EditText etEmail = findViewById( R.id.p_email );
        final EditText etPassword = findViewById( R.id.p_pass );
        btnDaftar = findViewById( R.id.btn_daftar );
        btnLogin2 = findViewById( R.id.back_to_login );

        btnLogin2.setOnClickListener( v -> {
            Intent intent = new Intent(SignUp.this, LoginActivity.class);
            startActivity( intent );
        } );
        btnDaftar.setOnClickListener( v -> {
            if (etNama.getText().toString().isEmpty()){
                Toast.makeText( getApplicationContext(), "Masukkan Nama", Toast.LENGTH_LONG ).show();
            }
            if (etTelepon.getText().toString().isEmpty()){
                Toast.makeText( getApplicationContext(), "Masukkan No Telepon", Toast.LENGTH_LONG ).show();
            }
            if (etEmail.getText().toString().isEmpty()){
                Toast.makeText( getApplicationContext(), "Masukkan Email", Toast.LENGTH_LONG ).show();
            }
            if (etPassword.getText().toString().isEmpty()){
                Toast.makeText( getApplicationContext(), "Masukkan Password", Toast.LENGTH_LONG ).show();
            }


            FirebaseAuth firebaseAuth= FirebaseAuth.getInstance();

            if (!(etNama.getText().toString().isEmpty() && etTelepon.getText().toString().isEmpty() &&
                    etEmail.getText().toString().isEmpty() && etPassword.getText().toString().isEmpty())){

                firebaseAuth.createUserWithEmailAndPassword(etEmail.getText().toString(), etPassword.getText().toString())
                        .addOnCompleteListener( task -> {
                            if(task.isSuccessful()){
                                String uid = task.getResult().getUser().getUid();
                                Users user = new Users(uid, etNama.getText().toString(),etTelepon.getText().toString(),etEmail.getText().toString(),etPassword.getText().toString(),0);
                                databaseReference.child("Users").child(uid).setValue(user);

                                Intent intent = new Intent(SignUp.this, HomeOrtuActivity.class);
                                Toast.makeText( getApplicationContext(), "Registrasi Berhasil", Toast.LENGTH_LONG ).show();
                                startActivity( intent );
                            }
                            else {
                                Toast.makeText( getApplicationContext(), task.getException().getLocalizedMessage(), Toast.LENGTH_LONG ).show();
                            }
                        } );
                }
            } );
        }


}