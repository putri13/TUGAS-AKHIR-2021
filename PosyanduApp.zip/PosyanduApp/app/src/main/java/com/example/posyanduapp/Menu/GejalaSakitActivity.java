package com.example.posyanduapp.Menu;

import android.os.Bundle;

import com.example.posyanduapp.Adapter.GejalaSakitAdapter;
import com.example.posyanduapp.R;
import com.google.android.material.tabs.TabLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

public class GejalaSakitActivity extends AppCompatActivity {


    TabLayout tabLayout;
    ViewPager viewPager;
    GejalaSakitAdapter gejalaSakitAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gejala_sakit);

        viewPager = findViewById(R.id.view_pager);
        tabLayout = findViewById(R.id.tabs);

        gejalaSakitAdapter = new GejalaSakitAdapter(getSupportFragmentManager());
        viewPager.setAdapter(gejalaSakitAdapter);

        tabLayout.setupWithViewPager(viewPager);
    }




    }
