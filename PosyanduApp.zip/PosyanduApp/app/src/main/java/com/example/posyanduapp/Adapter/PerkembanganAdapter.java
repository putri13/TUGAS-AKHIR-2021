package com.example.posyanduapp.Adapter;

import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.posyanduapp.R;
import com.example.posyanduapp.ViewHolder.DataPerkembangan;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class PerkembanganAdapter extends FirebaseRecyclerAdapter
                <DataPerkembangan, PerkembanganAdapter.PerkembanganViewHolder> {
    public PerkembanganAdapter(
            @NonNull FirebaseRecyclerOptions<DataPerkembangan> options)
    {
        super(options);
    }

    @Override
    protected void onBindViewHolder
            (@NonNull PerkembanganViewHolder holder, int position, @NonNull DataPerkembangan model) {
        holder.namaBalita.setText(model.getNmBalita());
        holder.ket1Perkembangan.setText(model.getKet1());
        holder.ket2Perkembangan.setText(model.getKet2());
        holder.ket3Perkembangan.setText(model.getKet3());
        holder.bthapus.setOnClickListener((v ->  {
                AlertDialog.Builder builder = new AlertDialog.Builder(holder.bthapus.getContext());
                builder.setTitle("Hapus Item");
                builder.setTitle("Apakah Anda yakin akan menghapus data ini?");

                builder.setPositiveButton("Ya", (dialog, i) -> FirebaseDatabase.getInstance().getReference().child("catatan_perkembangan")
                        .child(Objects.requireNonNull(getRef(position).getKey())).removeValue());
                builder.setNegativeButton("Tidak", (dialog, i) -> {

                });
                builder.show();
        }));



    }


    @NonNull
    @Override
    public PerkembanganViewHolder onCreateViewHolder
            (@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.activity_data_perkembangan, parent, false);
            return new PerkembanganViewHolder(view);


    }

    static class PerkembanganViewHolder extends RecyclerView.ViewHolder  {
            TextView namaBalita, ket1Perkembangan, ket2Perkembangan, ket3Perkembangan;
            Button bthapus;
            public PerkembanganViewHolder (@NonNull View itemView){
                super(itemView);

                namaBalita = itemView.findViewById(R.id.namaBalitaPer);
                ket1Perkembangan = itemView.findViewById(R.id.ket1);
                ket2Perkembangan = itemView.findViewById(R.id.ket2);
                ket3Perkembangan = itemView.findViewById(R.id.ket3);
                bthapus = itemView.findViewById(R.id.bt_hps_per);



    }

    }

}
