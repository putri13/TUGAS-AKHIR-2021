package com.example.posyanduapp.Adapter;

import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.posyanduapp.R;
import com.example.posyanduapp.ViewHolder.DataPemeriksaan;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class KMSAdapter extends FirebaseRecyclerAdapter

        <DataPemeriksaan, KMSAdapter.KMSViewHolder>{

        public KMSAdapter(
                @NonNull FirebaseRecyclerOptions<DataPemeriksaan> options)
        {
            super(options);
        }

        @Override
        protected void onBindViewHolder(
                @NonNull KMSViewHolder holder, int position, @NonNull DataPemeriksaan model) {

            holder.namaBalita.setText(model.getNamaBalita());
            holder.tglPemeriksaan.setText(model.getTglPemeriksaan());
            holder.ketPemeriksaan.setText(model.getKetPemeriksaan());
            holder.beratBadan.setText(model.getBeratBadan());
            holder.tinggiBadan.setText(model.getTinggiBadan());
            holder.lingkarKepala.setText(model.getLingkarKepala());

            holder.btHpsData.setOnClickListener((v ->  {

                AlertDialog.Builder builder = new AlertDialog.Builder(holder.btHpsData.getContext());
                builder.setTitle("Hapus Item");
                builder.setTitle("Apakah Anda yakin akan menghapus item?");

                builder.setPositiveButton("Ya", (dialog, i) -> FirebaseDatabase.getInstance().getReference().child("data_pemeriksaan")
                        .child(Objects.requireNonNull(getRef(position).getKey())).removeValue());
                builder.setNegativeButton("Tidak", (dialog, i) -> {
                });
                builder.show();
            }));



        }

        @NonNull
        @Override
        public KMSViewHolder
        onCreateViewHolder
                (@NonNull ViewGroup parent, int viewType){

            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.activity_data_pemeriksaan, parent, false);
            return new KMSViewHolder(view);
        }

        class KMSViewHolder extends RecyclerView.ViewHolder{

                TextView btUpd, btHpsData, namaBalita, tglPemeriksaan, ketPemeriksaan, beratBadan, tinggiBadan,lingkarKepala;
                public KMSViewHolder(@NonNull View itemView) {
                    super(itemView);

                    namaBalita = itemView.findViewById(R.id.namaBalita);
                    tglPemeriksaan = itemView.findViewById(R.id.tanggalPemeriksaan);
                    ketPemeriksaan = itemView.findViewById(R.id.et_bb );
                    beratBadan = itemView.findViewById(R.id.beratBadan);
                    tinggiBadan = itemView.findViewById(R.id.et_gender );
                    lingkarKepala = itemView.findViewById(R.id.lingkarKepala);
                    btHpsData = itemView.findViewById(R.id.bt_hps_kms);
                    //btUpd = itemView.findViewById(R.id.bt_edit_kms );

                }
        }
}
