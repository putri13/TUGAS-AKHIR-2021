package com.example.posyanduapp.Adapter;

import com.example.posyanduapp.Menu.Usia1;
import com.example.posyanduapp.Menu.Usia2;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class MakananAdapter extends FragmentPagerAdapter {
    public MakananAdapter(@NonNull FragmentManager fragmentManager){
        super(fragmentManager);
    }

    @NonNull
    @Override
    public Fragment getItem (int position){
        Fragment fragment = null;
        if (position == 0)
            fragment = new Usia1();
        else if (position == 1)
            fragment = new Usia2();
        return fragment;
    }

    @Override
    public int getCount() {
        return 2;
    }

    @Override
    public CharSequence getPageTitle (int position){
        String title = null;
        if (position == 0)
            title = "Usia 6-9 bulan";
        else if (position == 1)
            title = "Usia 9-12 bulan";
        return title;
    }
}
