package com.example.posyanduapp.ViewHolder;

import android.os.Bundle;

import com.example.posyanduapp.Adapter.ImunisasiAdapter;
import com.example.posyanduapp.R;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ListDataImunisasi extends AppCompatActivity {

    ImunisasiAdapter imunisasiAdapter;
    DatabaseReference dbReferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_data_imunisasi);

        dbReferences = FirebaseDatabase.getInstance().getReference().child("catatan_imunisasi");
        RecyclerView recyclerView4 = findViewById(R.id.list_imun);

        recyclerView4.setLayoutManager(new LinearLayoutManager(this));

        FirebaseRecyclerOptions<DataImunisasi>
                options = new FirebaseRecyclerOptions.Builder<DataImunisasi>()
                .setQuery(dbReferences, DataImunisasi.class)
                .build();

        imunisasiAdapter = new ImunisasiAdapter(options);
        recyclerView4.setAdapter(imunisasiAdapter);
        recyclerView4.setHasFixedSize(true);


    }

    @Override
    protected void onStart(){
        super.onStart();
        imunisasiAdapter.startListening();
    }
    @Override
    protected void onStop(){
        super.onStop();
        imunisasiAdapter.stopListening();
    }
}