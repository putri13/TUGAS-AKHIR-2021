package com.example.posyanduapp.ViewHolder;

public class DataPerkembangan  {

    private String Perkembangan;


    private String nmBalita;
    private String ket1;
    private String ket2;
    private String ket3;
    private String perkembangan1a;
    private String perkembangan1b;
    private String perkembangan1c;
    private String perkembangan2a;
    private String perkembangan2b;
    private String perkembangan2c;
    private String perkembangan2d;
    private String perkembangan2e;
    private String perkembangan3a;
    private String perkembangan3b;
    private String perkembangan3c;
    private String perkembangan3d;
    private String perkembangan3e;
    private String perkembangan3f;


    public String getNmBalita() {
        return nmBalita;
    }

    public void setNmBalita(String nmBalita) {
        this.nmBalita = nmBalita;
    }

    public String getKet1() {
        return ket1;
    }

    public void setKet1(String ket1) {
        this.ket1 = ket1;
    }

    public String getKet2() {
        return ket2;
    }

    public void setKet2(String ket2) {
        this.ket2 = ket2;
    }

    public String getKet3() {
        return ket3;
    }

    public void setKet3(String ket3) {
        this.ket3 = ket3;
    }

    public String getPerkembangan1a() {
        return perkembangan1a;
    }

    public void setPerkembangan1a(String perkembangan1a) {
        this.perkembangan1a = perkembangan1a;
    }

    public String getPerkembangan1b() {
        return perkembangan1b;
    }

    public void setPerkembangan1b(String perkembangan1b) {
        this.perkembangan1b = perkembangan1b;
    }

    public String getPerkembangan1c() {
        return perkembangan1c;
    }

    public void setPerkembangan1c(String perkembangan1c) {
        this.perkembangan1c = perkembangan1c;
    }

    public String getPerkembangan2a() {
        return perkembangan2a;
    }

    public void setPerkembangan2a(String perkembangan2a) {
        this.perkembangan2a = perkembangan2a;
    }

    public String getPerkembangan2b() {
        return perkembangan2b;
    }

    public void setPerkembangan2b(String perkembangan2b) {
        this.perkembangan2b = perkembangan2b;
    }

    public String getPerkembangan2c() {
        return perkembangan2c;
    }

    public void setPerkembangan2c(String perkembangan2c) {
        this.perkembangan2c = perkembangan2c;
    }

    public String getPerkembangan2d() {
        return perkembangan2d;
    }

    public void setPerkembangan2d(String perkembangan2d) {
        this.perkembangan2d = perkembangan2d;
    }

    public String getPerkembangan2e() {
        return perkembangan2e;
    }

    public void setPerkembangan2e(String perkembangan2e) {
        this.perkembangan2e = perkembangan2e;
    }

    public String getPerkembangan3a() {
        return perkembangan3a;
    }

    public void setPerkembangan3a(String perkembangan3a) {
        this.perkembangan3a = perkembangan3a;
    }

    public String getPerkembangan3b() {
        return perkembangan3b;
    }

    public void setPerkembangan3b(String perkembangan3b) {
        this.perkembangan3b = perkembangan3b;
    }

    public String getPerkembangan3c() {
        return perkembangan3c;
    }

    public void setPerkembangan3c(String perkembangan3c) {
        this.perkembangan3c = perkembangan3c;
    }

    public String getPerkembangan3d() {
        return perkembangan3d;
    }

    public void setPerkembangan3d(String perkembangan3d) {
        this.perkembangan3d = perkembangan3d;
    }

    public String getPerkembangan3e() {
        return perkembangan3e;
    }

    public void setPerkembangan3e(String perkembangan3e) {
        this.perkembangan3e = perkembangan3e;
    }

    public String getPerkembangan3f() {
        return perkembangan3f;
    }

    public void setPerkembangan3f(String perkembangan3f) {
        this.perkembangan3f = perkembangan3f;
    }



    public DataPerkembangan(){

    }

    public String getPerkembangan(){
        return Perkembangan;
    }

    public void setPerkembangan (String perkembangan){
        Perkembangan = perkembangan;
    }




}