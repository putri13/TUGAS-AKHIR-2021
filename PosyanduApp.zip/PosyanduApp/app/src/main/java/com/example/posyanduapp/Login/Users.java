package com.example.posyanduapp.Login;

public class Users {


    private String Nama;
    private String Telepon;
    private String Uid;
    private String Email;
    private String Password;
    private int usertype;

    public Users(String uid, String nama, String telepon, String email, String password,  int usertype) {
        Uid = uid;
        Nama = nama;
        Telepon = telepon;
        Email = email;
        Password = password;
        usertype = usertype;
    }

    public Users(){

    }


    public String getNama() {
        return Nama;
    }

    public void setNama(String nama) {
        Nama = nama;
    }

    public String getTelepon() {
        return Telepon;
    }

    public void setTelepon(String telepon) {
        Telepon = telepon;
    }

    public String getUid() {
        return Uid;
    }

    public void setUid(String uid) {
        Uid = uid;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public int getUsertype() {
        return usertype;
    }

    public void setUsertype(int usertype) {
        this.usertype = usertype;
    }








}
