 package com.example.posyanduapp.Menu;

 import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.posyanduapp.Login.Users;
import com.example.posyanduapp.R;
import com.example.posyanduapp.ViewHolder.ListBalita;
import com.example.posyanduapp.ViewHolder.RegistBalita;
 import com.example.posyanduapp.ViewHolder.UpdateBalita;
 import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import static android.text.TextUtils.isEmpty;

public class RegistActivity extends AppCompatActivity {


    EditText namaAnak;
    EditText tlAnak;
    EditText anakKe;
    EditText gender;
    EditText nikAnak;
    EditText bbAnak;
    EditText nmOrtu1;
    EditText nmOrtu2;
    EditText nikOrtu1;
    EditText nikOrtu2;
    EditText ntOrtu;
    EditText alOrtu;
    int maxId = 0;
    Spinner mSpinner;
    //String text = spinner.getSelectedItem().toString();
    FirebaseDatabase firebaseDatabase;
    FirebaseAuth firebaseAuth;

    List<String> nama;

    DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("regist_balita");
    DatabaseReference db = FirebaseDatabase.getInstance().getReference().child( "Users" ).child( "Users" );
    Users users;
    UpdateBalita updateBalita;
    RegistBalita registBalita;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regist);

        firebaseAuth = FirebaseAuth.getInstance();
        //userid = Objects.requireNonNull( firebaseAuth.getCurrentUser() ).getUid();

        nama = new ArrayList<>();
        mSpinner = findViewById( R.id.namaortu );
        namaAnak = findViewById(R.id.nm_anak);
        tlAnak = findViewById(R.id.et_tl_anak );
        anakKe = findViewById(R.id.et_anak_ke );
        gender = findViewById(R.id.et_gender );
        nikAnak = findViewById(R.id.et_nik_anak );
        bbAnak = findViewById(R.id.et_bb );
        nmOrtu1 = findViewById(R.id.et_nm_ortu1 );
        nmOrtu2 = findViewById(R.id.et_nm_ortu2 );
        nikOrtu1 = findViewById(R.id.et_nik_ortu1 );
        nikOrtu2 = findViewById(R.id.et_nik_ortu2 );
        ntOrtu = findViewById(R.id.et_nt_ortu );
        alOrtu = findViewById(R.id.et_al_ortu );
        //id = findViewById( R.id.idAnak );

        firebaseDatabase = FirebaseDatabase.getInstance();

        registBalita = new RegistBalita();
        users = new Users();

        Button buttonSimpan = findViewById(R.id.bt_detail_apdet_regist );
        Button buttonLihatData = findViewById(R.id.button_lhtData);
        //Button buttonApdetData = findViewById( R.id.bt_edit_regist );

        buttonLihatData.setOnClickListener((View v) -> startActivity( new Intent( RegistActivity.this, ListBalita.class ) ) );

        db.child( "Users" ).child( "Users");
        db.addValueEventListener( new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                    String spinnerNama = childSnapshot.child( "nama" ).getValue( String.class );
                    nama.add( spinnerNama );
                }
                ArrayAdapter<String> a = new ArrayAdapter<>( RegistActivity.this, android.R.layout.simple_spinner_dropdown_item, nama );
                a.setDropDownViewResource( android.R.layout.simple_spinner_item );
                mSpinner.setAdapter( a );
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        } );



        buttonSimpan.setOnClickListener((View v) -> {
            registBalita = new RegistBalita();
            registBalita.setSpinner( mSpinner.getSelectedItem().toString());

            reference.child(String.valueOf( maxId+1 )).setValue( registBalita );



            //String id  = reference.push().getKey();
            //String namaOrtu = te.setAdapter(  );
            String namaLengkapAnak = namaAnak.getText().toString();
            String ttlAnak = tlAnak.getText().toString();
            String anakKeBerapa = anakKe.getText().toString();
            String genderAnak = gender.getText().toString();
            String nik_Anak = nikAnak.getText().toString();
            String beratBadanAnak = bbAnak.getText().toString();
            String namaOrtu1 = nmOrtu1.getText().toString();
            String namaOrtu2 = nmOrtu2.getText().toString();
            String nik_Ortu1 = nikOrtu1.getText().toString();
            String nik_Ortu2 = nikOrtu2.getText().toString();
            String noTeleponOrtu = ntOrtu.getText().toString();
            String alamatOrtu = alOrtu.getText().toString();

            if (isEmpty(namaLengkapAnak) && isEmpty(ttlAnak) && isEmpty(anakKeBerapa) &&
                    isEmpty(genderAnak) && isEmpty(nik_Anak) && isEmpty(beratBadanAnak) && isEmpty(namaOrtu1) && isEmpty(namaOrtu2) &&
                    isEmpty(nik_Ortu1) && isEmpty(nik_Ortu2) && isEmpty(noTeleponOrtu) && isEmpty(alamatOrtu)) {
                Toast.makeText(RegistActivity.this, "Tambahkan Data Anda", Toast.LENGTH_LONG).show();
            } else {
                addDatatoFirebase(namaLengkapAnak, ttlAnak, anakKeBerapa, genderAnak, nik_Anak,
                        beratBadanAnak, namaOrtu1, namaOrtu2, nik_Ortu1, nik_Ortu2, noTeleponOrtu, alamatOrtu);
            }
        });

    }


    private void addDatatoFirebase(String nmAnak, String tAnak, String anKe, String gnder, String nAn,
                                   String bAn, String namOrtu1, String namOrtu2, String nOrtu1, String nOrtu2, String ntelOrtu, String aOrtu) {
        //registBalita.setSpinner( spinner );
        registBalita.setNamaAnak(nmAnak);
        registBalita.setTtlAnak(tAnak);
        registBalita.setAnakKe(anKe);
        registBalita.setGender(gnder);
        registBalita.setNikAnak(nAn);
        registBalita.setBbAnak(bAn);
        registBalita.setNamaOrtu1(namOrtu1);
        registBalita.setNamaOrtu2(namOrtu2);
        registBalita.setNikOrtu1(nOrtu1);
        registBalita.setNikOrtu2(nOrtu2);
        registBalita.setNoTeleponOrtu(ntelOrtu);
        registBalita.setAlamatOrtu(aOrtu);
        //registBalita.setId( id );

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                reference.child(nmAnak).setValue(registBalita);
                Toast.makeText(RegistActivity.this, "Data Ditambahkan", Toast.LENGTH_LONG).show();
                if(snapshot.exists()){
                    maxId = (int) snapshot.getChildrenCount();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(RegistActivity.this, "Gagal Menambahkan Data" + error, Toast.LENGTH_LONG).show();
            }
        });


    }
    }




