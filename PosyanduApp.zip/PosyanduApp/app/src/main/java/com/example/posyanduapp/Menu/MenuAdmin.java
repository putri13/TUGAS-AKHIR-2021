package com.example.posyanduapp.Menu;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.posyanduapp.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

public class MenuAdmin extends Fragment implements View.OnClickListener {

    FloatingActionButton floatingActionButton;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.admin_menu,container,false);

        floatingActionButton = view.findViewById(R.id.btn_greeting);
        CardView kmsCard = view.findViewById(R.id.kms);
        CardView kiaCard = view.findViewById(R.id.kia);
        CardView imunCard = view.findViewById(R.id.imun);
        CardView tips1Card = view.findViewById(R.id.tips1);
        CardView tips2Card = view.findViewById(R.id.tips2);


        kmsCard.setOnClickListener(this);
        kiaCard.setOnClickListener(this);
        imunCard.setOnClickListener(this);
        tips1Card.setOnClickListener(this);
        tips2Card.setOnClickListener(this);

        floatingActionButton.setOnClickListener(v -> startActivity(new Intent(getActivity(), RegistActivity.class)));
        return view;
    }

    @Override
    public void onClick(View v) {
        Intent intent;

        switch (v.getId()){
            case R.id.kms : intent = new Intent(getActivity(), KMSActivity.class);
                startActivity(intent);
                break;
            case R.id.kia : intent = new Intent(getActivity(), PerkembanganActivity.class);
                startActivity(intent);
                break;
            case R.id.imun : intent = new Intent(getActivity(), ImunisasiActivity.class);
                startActivity(intent);
                break;
            case R.id.tips1 : intent = new Intent(getActivity(), MakananActivity.class);
                startActivity(intent);
                break;
            case R.id.tips2 : intent = new Intent(getActivity(), GejalaSakitActivity.class);
                startActivity(intent);
                break;
        }
    }
}

