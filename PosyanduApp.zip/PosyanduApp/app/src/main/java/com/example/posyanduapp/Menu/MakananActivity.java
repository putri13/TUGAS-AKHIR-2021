package com.example.posyanduapp.Menu;

import android.os.Bundle;

import com.example.posyanduapp.Adapter.MakananAdapter;
import com.example.posyanduapp.R;
import com.google.android.material.tabs.TabLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

public class MakananActivity extends AppCompatActivity {

    TabLayout tabLayout2;
    ViewPager viewPager2;
    MakananAdapter makananAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_makanan);

        viewPager2 = findViewById(R.id.view_pager2);
        tabLayout2 = findViewById(R.id.tab_2);

        makananAdapter = new MakananAdapter(getSupportFragmentManager());
        viewPager2.setAdapter(makananAdapter);

        tabLayout2.setupWithViewPager(viewPager2);
    }
}