package com.example.posyanduapp.Adapter;

import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.posyanduapp.R;
import com.example.posyanduapp.ViewHolder.DataImunisasi;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ImunisasiAdapter extends FirebaseRecyclerAdapter
                <DataImunisasi, ImunisasiAdapter.ImunisasiViewHolder> {


    public ImunisasiAdapter(
            @NonNull FirebaseRecyclerOptions<DataImunisasi> options)
    {
        super(options);
    }

    @Override
    protected void onBindViewHolder(
            @NonNull ImunisasiViewHolder holder, int position, @NonNull DataImunisasi model) {

        holder.nmBalita.setText(model.getNamaBalita());
        holder.ketVaksin.setText(model.getKetImunisasi());
        holder.btHps.setOnClickListener((v ->  {
            AlertDialog.Builder builder = new AlertDialog.Builder(holder.btHps.getContext());
            builder.setTitle("Hapus Item");
            builder.setTitle("Apakah Anda yakin akan menghapus data ini?");

            builder.setPositiveButton("Ya", (dialog, i) -> FirebaseDatabase.getInstance().getReference().child("catatan_imunisasi")
                    .child(getRef(position).getKey()).removeValue());
            builder.setNegativeButton("Tidak", (dialog, i) -> {

            });
            builder.show();
        }));
    }

    @NonNull
    @Override
    public ImunisasiViewHolder
    onCreateViewHolder
            (@NonNull ViewGroup parent, int viewType){

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_data_imunisasi, parent, false);
        return new ImunisasiAdapter.ImunisasiViewHolder(view);
    }

    class ImunisasiViewHolder extends RecyclerView.ViewHolder {
        TextView btHps, nmBalita, ketVaksin;
        public ImunisasiViewHolder(@NonNull View itemView){
            super(itemView);

            nmBalita = itemView.findViewById(R.id.namaBalitaImun);
            ketVaksin = itemView.findViewById(R.id.ket_imun);
            btHps = itemView.findViewById(R.id.bt_hps_imu);

        }
    }




}
