package com.example.posyanduapp.ViewHolder;

import android.os.Bundle;

import com.example.posyanduapp.Adapter.BalitaAdapter;
import com.example.posyanduapp.R;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


public class ListBalita extends AppCompatActivity {

    private RecyclerView recyclerView;
    BalitaAdapter balitaAdapter;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_balita);

        databaseReference = FirebaseDatabase.getInstance().getReference().child("regist_balita");
        recyclerView = findViewById(R.id.list_balita);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        FirebaseRecyclerOptions<RegistBalita>
                options = new FirebaseRecyclerOptions.Builder<RegistBalita>()
                .setQuery(databaseReference, RegistBalita.class)
                .build();

        balitaAdapter = new BalitaAdapter(options);
        recyclerView.setAdapter(balitaAdapter);
        recyclerView.setHasFixedSize( true );
        recyclerView.setLayoutManager( new LinearLayoutManager( this) );

    }

    @Override
    protected void onStart(){
        super.onStart();
        balitaAdapter.startListening();
    }
    @Override
    protected void onStop(){
        super.onStop();
        balitaAdapter.stopListening();
    }

}